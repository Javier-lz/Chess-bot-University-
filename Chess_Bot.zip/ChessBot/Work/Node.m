classdef Node
    %The node is an object that represent the position of the board at a
    %given time, the parameters range from the current position, and the
    %possible moves taken in that position. 
    %   Detailed explanation goes here
    
    properties
        state BoardState,
        parent BoardState,
        children BoardState,
        N_parent double,
        n_taken double,
        success double,
    end
    
    methods
        function obj = Node(BoardState)
            %UNTITLED Construct an instance of this class
            %   Detailed explanation goes here
            obj.state=BoardState
            obj.parent=[]
            obj.children=[]
            obj.N_parent=0
            obj.n_taken=0
            obj.success=0
        end
        
        
    end
end

