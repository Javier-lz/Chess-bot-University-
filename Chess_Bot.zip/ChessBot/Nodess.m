classdef Nodess < handle
   

       properties
        state           % Estado actual del tablero
        parent          % Nodo padre
        children        % Arreglo de nodos hijos
        N_parent double % Número de veces que el padre ha sido visitado
        n_taken double  % Número de veces que se ha tomado este movimiento
        success double  
    end

    methods
        function obj = Nodess(FenStr)
            % Constructor de Nodess
            if nargin > 0
                % Crea una copia del objeto chessmaster usando memoria temporal
                obj.state = deepClone(FenStr);
            end
            obj.parent = Nodess.empty;
            obj.children = Nodess.empty;
            obj.N_parent = 0;
            obj.n_taken = 0;
            % success es el límite superior de confianza (Upper Confidence Bound).
            % Una medida que considera exploración y explotación.
            obj.success = 0;
        end
        function addChild(obj, childNodess)
            % Relaciona dos nodos añadiendo un hijo a obj y un padre a childNodess
           obj.children(end+1) = childNodess;
           childNodess.parent(end+1) = obj;
        end

        function value = calc_success(obj)
            % Crea el límite superior de confianza mediante una fórmula.
            % Se suman 10^-8 y 10^-7 para evitar errores de log(0) y división entre 0.
            value = obj.success + 0.01*sqrt(log(obj.N_parent+1+10^-8)/3*(obj.n_taken + 10^(-7)));
        end

        function deep_node = expandNodess(obj, color)
            % blanco = 1
            % negro = 2
            % La función expandNodess recorre el árbol eligiendo el mayor
            % límite superior de confianza entre los hijos hasta llegar a un nodo sin hijos.
            if isempty(obj.children)
                deep_node = obj;
                return  
            end
            if color == 1
                max_ucb = -10e16;
                for i = 1:length(obj.children)
                    tmp = calc_success(obj.children(i));
                    if(tmp > max_ucb)
                        max_ucb = tmp;
                        deep_node = obj.children(i);
                    end
                end
                deep_node = expandNodess(deep_node, mod(color,2)+1);
                return
            elseif color == 2
                min_ucb = 10e16;
                for i = 1:length(obj.children)
                    tmp = calc_success(obj.children(i));
                    if(tmp < min_ucb)
                        min_ucb = tmp;
                        deep_node = obj.children(i);
                    end
                end
                deep_node = expandNodess(deep_node, mod(color,2)+1);
            end
        end

        function recalculate(obj, reward)
            % Dado un valor de recompensa y un nodo, la función recorre
            % hacia arriba hasta llegar a la raíz.
            % Los cambios afectan al número de veces que se ha tomado el nodo
            % y a quién beneficia: x<0 beneficia a negras; x>0 beneficia a blancas.
            while ~isempty(obj.parent)
                obj.n_taken = obj.n_taken + 1;
                obj.success = obj.success + reward;
                obj = obj.parent;
            end
            obj.n_taken = obj.n_taken + 1;
            obj.success = obj.success + reward;
            obj = obj.parent;
        end

        function [reward_rol, node] = exploration(obj, CM, color)
            % Si la posición del juego es crítica: Jaque, Jaque Mate o 
            % Tablas, el juego termina con una recompensa.
            reward_rol = 0;
            if CM.isGameOver || CM.drawh2.Enable == 1 || CM.drawh3.Enable == 1
                if CM.winner == 1
                    reward_rol = 10;
                    node = obj;
                    return
                elseif CM.winner == 2
                    reward_rol = -10;
                    node = obj;
                    return
                else
                    reward_rol = 0;
                    node = obj;
                    return
                end
            else
                moves = AllMoves(CM.BS, CM.turnColor);
                for i = 1:length(moves)
                    % Intenta los movimientos; si no es válido, retorna cadena vacía.
                    a = CM.MakeMove(char(moves(i)));
                    if strcmp(a, '')
                        continue
                    end
                    % Verifica si el movimiento genera un estado crítico:
                    % Fin del juego / Jaque / Tablas
                    % Da resultado positivo si favorece a blancas, negativo si favorece a negras.
                    if CM.isGameOver || CM.drawh2.Enable == 1 || CM.drawh3.Enable == 1
                        if CM.winner == 1
                            reward_rol = 10;
                            node = Nodess(CM);
                            addChild(obj, node);
                            return
                        elseif CM.winner == 2
                            reward_rol = -10;
                            node = Nodess(CM);
                            addChild(obj, node);
                            return
                        else
                            reward_rol = 0;
                            node = Nodess(CM);
                            addChild(obj, node);
                            return
                        end
                    elseif CM.BS.blackInCheck == 1
                        node = Nodess(CM);
                        reward_rol = 0.5;
                        addChild(obj, node);
                        return
                    elseif CM.BS.whiteInCheck == 1
                        node = Nodess(CM);
                        reward_rol = -0.5;
                        addChild(obj, node);
                        return 
                    end
                    % Crea una nueva posición alcanzable desde el estado inicial
                    node = Nodess(CM);
                    % Añade relación de padre e hijo entre nodos
                    addChild(obj, node);
                    % Restaura el estado inicial
                    CM.Undo
                end
                % Selecciona una muestra aleatoria (requiere el add-on de estadísticas)
                random_child = datasample(obj.children, 1);
                % Cambia el estado actual al juego aleatorio elegido
                CM.LoadGame(random_child.state, 'End')
                % Llamada recursiva hasta llegar a un estado crítico
                [reward_rol, node] = exploration(random_child, CM, mod(CM.turnColor,2)+1);
                CM.Undo
            end
        end

        function [chosen_move] = MonteCarloTreeSearch(curNodess, CM, over, color, iterations)
            % Simulación Monte Carlo: devuelve el mejor movimiento
            % según el muestreo aleatorio.

            % Si el juego ha terminado, no hay movimientos posibles
            if over
                chosen_move = [];
                return 
            end

            % states_moves es un hashmap que asocia un estado con el
            % movimiento necesario para alcanzarlo
            all_moves = AllMoves(CM.BS, CM.turnColor);
            states_moves = containers.Map('KeyType', 'char', 'ValueType', 'any');

            % Guarda todos los movimientos posibles en el mapa
            for i = 1:length(all_moves)
                a = CM.MakeMove(char(all_moves(i)));
                if strcmp(a, '')
                    continue
                end
                % Crea clave única a partir del estado del tablero
                vKey = validKey(CM.GetFENstr);
                CM.Undo;
                states_moves(vKey) = [all_moves(i)];
            end

            % Realiza un número de simulaciones
            while iterations > 0
                LoadGame(CM, curNodess.state, 'End')
                if color == 1
                    origin = expandNodess(curNodess, 1);
                    LoadGame(CM, origin.state, 'End');
                    disp(origin)
                    [reward, origin] = exploration(origin, CM, 1);
                    disp(origin)
                    recalculate(origin, reward);
                    iterations = iterations - 1;
                elseif color == 2
                    origin = expandNodess(curNodess, 2);
                    LoadGame(CM, origin.state, 'End');
                    [reward, origin] = exploration(origin, CM, 2);
                    recalculate(origin, reward);
                    iterations = iterations - 1;
                end
            end

            if color == 1
                mx = -10e16;
                chosen_move = [];
                for i = 1:length(curNodess.children)
                    tmp = calc_success(curNodess.children(i));
                    if(tmp > mx)
                        mx = tmp;
                        tp = deepClone(CM);
                        CM.LoadGame(curNodess.children(i).state, 'End');
                        vkey = validKey(CM.GetFENstr);
                        CM.LoadGame(tp, 'End');
                        chosen_move = states_moves(vkey);
                    end
                end
            end
            if color == 2
                mx = 10e16;
                chosen_move = [];
                for i = 1:length(curNodess.children)
                    tmp = calc_success(curNodess.children(i));
                    if(tmp < mx)
                        mx = tmp;
                        tp = deepClone(CM);
                        CM.LoadGame(curNodess.children(i).state, 'End');
                        vkey = validKey(CM.GetFENstr);
                        CM.LoadGame(tp, 'End');
                        chosen_move = states_moves(vkey);
                    end
                end
            end
            CM.LoadGame(curNodess.state, 'Beginning')
        end

        % Intentos fallidos de serializar el árbol / guardarlo para entrenamiento futuro
        function treeStruct = serialize(obj)
            % Serializa el nodo actual y su subárbol
            treeStruct.state = obj.state;
            treeStruct.N_parent = obj.N_parent;
            treeStruct.n_taken = obj.n_taken;
            treeStruct.success = obj.success;

            % Serialización recursiva de hijos
            if ~isempty(obj.children)
                treeStruct.children = cell(1, numel(obj.children));
                for i = 1:numel(obj.children)
                    treeStruct.children{i} = obj.children(i).serialize();
                end
            else
                treeStruct.children = [];
            end
        end

        function node = deserializeTree(treeStruct)
            node = Nodess(treeStruct.state);
            node.N_parent = treeStruct.N_parent;
            node.n_taken = treeStruct.n_taken;
            node.success = treeStruct.success;

            if ~isempty(treeStruct.children)
                for i = 1:numel(treeStruct.children)
                    node.children(i) = deserializeTree(treeStruct.children{i});
                    node.children(i).parent = node;
                end
            end
        end
    end
