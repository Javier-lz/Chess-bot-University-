function clonedObj = deepClone(originalObj)

    clonedObj = tempname;
    %Saves the game on the clondedObj directory as a temporary file. This
    %is then used as the state of the node. 
    SaveGame(originalObj,clonedObj)
    
   

   
end
