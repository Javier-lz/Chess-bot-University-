function legalMovesLAN = AllMoves(boardState, color)

    legalMovesLAN = {};
    

    switch color
        case ChessPiece.WHITE
            pieces = boardState.whitePieces;
            opponentColor = ChessPiece.BLACK;
        case ChessPiece.BLACK
            pieces = boardState.blackPieces;
            opponentColor = ChessPiece.WHITE;
    end
    

    files = 'abcdefgh';
    ranks = '12345678';

    for k = 1:length(pieces)
        piece = pieces{k};
        [ii, jj] = piece.ValidMoves();
        
        for m = 1:length(ii)
            toi = ii(m); toj = jj(m);
            
            if ~piece.IsCheckingMove(toi, toj)

                moveStr = getMoveString(piece, toi, toj);
                
         
                if piece.ID == Pawn.ID && ...
                   ((color == ChessPiece.WHITE && toj == 8) || ...
                    (color == ChessPiece.BLACK && toj == 1))
                    promotions = {'Q','R','B','N'};
                    for p = 1:length(promotions)
                        legalMovesLAN{end+1} = [moveStr promotions{p}];
                    end
                else
                    legalMovesLAN{end+1} = moveStr;
                end
            end
        end
    end
    

    king = boardState.KingOfColor(color);
    if ~isnan(king)
        [kingsideValid, ~, ~] = boardState.IsValidCastle(king.i, king.j, king.i+2, king.j);
        [queensideValid, ~, ~] = boardState.IsValidCastle(king.i, king.j, king.i-2, king.j);
        
        if kingsideValid
            start = [files(king.i) ranks(king.j)];
            dest = [files(king.i+2) ranks(king.j)];
            legalMovesLAN{end+1} = [start dest];  % e.g., 'e1g1'
        end
        
        if queensideValid
            start = [files(king.i) ranks(king.j)];
            dest = [files(king.i-2) ranks(king.j)];
            legalMovesLAN{end+1} = [start dest];  % e.g., 'e1c1'
        end
    end
end

function moveStr = getMoveString(piece, toi, toj)
    files = 'abcdefgh';
    ranks = '12345678';
    
    startSquare = [files(piece.i) ranks(piece.j)];
    destSquare = [files(toi) ranks(toj)];
    

    moveStr = [startSquare destSquare];
end