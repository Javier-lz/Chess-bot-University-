
Los archivos importantes propios son: 

validKey
Bot
deepClone
Nodess


Los demás son parte de la instalación de ChessMaster pero debido a que se 
han modificado algunos archivos la instalacion típica mediante matlab impediría el funcionamiento
del Bot. 

Para iniciar el Bot se debe ejecutar el archivo Bot.m . 
