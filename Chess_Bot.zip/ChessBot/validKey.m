function [validKey] = validKey(FEN)


%Reemplazar los valores inválidos para una clave hash por '_'
validKey = regexprep(FEN, {'/', ' ', '-', '\d+'}, {'_', '_', '_', '_'}); 

% Asegurarse que el inicio sea una letra, de otro modo la clave fallaría. 
if ~isletter(validKey(1))
    validKey = ['FEN_', validKey]; 
end

