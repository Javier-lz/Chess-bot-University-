




color=1;
CM = ChessMaster()

CM.enablePopups='false'

%d2d4 f2f3

s=Nodess(CM)
list={};



result=MonteCarloTreeSearch(s,CM,CM.isGameOver,color,50)
list(end +1)=result




















